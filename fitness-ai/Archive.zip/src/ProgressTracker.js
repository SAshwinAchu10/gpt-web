import React from 'react';

const ProgressTracker = () => {
    const [workouts, setWorkouts] = React.useState([
        { id: 1, name: 'Tabata at home', day: 'Today', completed: false, date: null },
        { id: 2, name: 'Resistance training at the gym', day: 'Tomorrow', completed: false, date: null },
        { id: 3, name: 'Rest', day: 'Sunday', completed: false, date: null },
        { id: 4, name: 'Treadmill at the gym', day: 'Monday', completed: false, date: null },
        { id: 5, name: 'Resistance training at home', day: 'Tuesday', completed: false, date: null },
        { id: 6, name: 'Rest', day: 'Wednesday', completed: false, date: null },
        { id: 7, name: 'Rest', day: 'Thursday', completed: false, date: null },
    ]);

    React.useEffect(() => {
        const savedWorkouts = JSON.parse(localStorage.getItem('workouts'));
        if (savedWorkouts) {
            setWorkouts(savedWorkouts);
        }
    }, []);

    const handleComplete = (id) => {
        const updatedWorkouts = workouts.map(workout => {
            if (workout.id === id) {
                workout.completed = !workout.completed;
                workout.date = workout.completed ? new Date().toLocaleDateString() : null;
            }
            return workout;
        });

        setWorkouts(updatedWorkouts);
        localStorage.setItem('workouts', JSON.stringify(updatedWorkouts));
    };

    const getCompletedCount = () => {
        return workouts.filter(workout => workout.completed).length;
    };

    return (
        <div style={{ textAlign: 'left',display:"flex"}}>
          <div style={{width:"50%"}}>
            <h1>Progress</h1>
            <h2>Workout - Week 1</h2>
            <ul>
                {workouts.map(workout => (
                    <li key={workout.id}>
                        <label>
                            <input
                                type="checkbox"
                                checked={workout.completed}
                                onChange={() => handleComplete(workout.id)}
                            />
                            {workout.name} - {workout.day}
                        </label>
                        {workout.completed && (
                            <div>
                                <p>Completed on: {workout.date}</p>
                            </div>
                        )}
                    </li>
                ))}
            </ul>
                </div>
                <div  style={{width:"50%"}}>
            <ProgressChart completed={getCompletedCount()} total={workouts.length} />
            </div>
        </div>
    );
};

const ProgressChart = ({ completed, total }) => {
    const percentage = (completed / total) * 100;

    return (
        <div style={{ textAlign: 'left', marginTop: '20px' }}>
            <h3>Progress</h3>
            <div style={{ display: 'flex', alignItems: 'flex-end', height: '200px' }}>
                {[...Array(total)].map((_, index) => (
                    <div
                        key={index}
                        style={{
                            width: '20px',
                            height: `${completed > index ? '100%' : '0%'}`,
                            backgroundColor: completed > index ? '#76c7c0' : '#e0e0e0',
                            marginRight: '5px',
                            transition: 'height 0.5s',
                        }}
                    />
                ))}
            </div>
            <p>{completed} out of {total} workouts completed</p>
        </div>
    );
};

export default ProgressTracker;
